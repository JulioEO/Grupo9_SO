//Programa 1
// syscall read(), open() e close()
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
int main(){
	char texto[12];
	int arq = open("arquivo",O_RDONLY);
	read(arq,texto,12);
	printf("%s\n", texto);
	close(arq);
	return 0;
}
